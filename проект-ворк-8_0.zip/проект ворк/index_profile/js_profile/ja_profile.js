const profile = document.querySelector(".header_profile");
const profileBlock = document.querySelector(".header_profile_block");

profile.addEventListener("click", (e) => {
   // Проверяем, что клик был именно по шапке профиля, а не по ссылкам внутри открытого меню
   if (
      e.target.closest(".header_profile") &&
      !e.target.closest(".header_profile_block")
   ) {
      const isOpen = profileBlock.style.display === "flex";
      profileBlock.style.display = isOpen ? "none" : "flex";
   }
});

// Закрытие при клике на любое пустое место сайта
document.addEventListener("click", (e) => {
   if (!profile.contains(e.target)) {
      profileBlock.style.display = "none";
   }
});
